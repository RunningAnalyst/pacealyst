import React, { useEffect, useRef, useState } from 'react';
import { BackHandler, Linking, Share, useColorScheme } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import html from './src/pacealyst-html';

// Feste Herkunft, damit localStorage (Eingaben) zwischen App-Starts erhalten bleibt
const ORIGIN = 'https://pacealyst.app/';

export default function App() {
  const scheme = useColorScheme();
  const web = useRef(null);
  const [canGoBack, setCanGoBack] = useState(false);
  const bg = scheme === 'dark' ? '#0F1315' : '#EEF1EF';

  // Android-Zurück-Taste: erst zwischen Tabs zurück, dann App verlassen
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack && web.current) { web.current.goBack(); return true; }
      return false;
    });
    return () => sub.remove();
  }, [canGoBack]);

  const onMessage = (e) => {
    try {
      const msg = JSON.parse(e.nativeEvent.data);
      if (msg.type === 'share' && msg.text) Share.share({ message: msg.text });
    } catch (_) {}
  };

  // Interne Navigation (Tabs per #anker) bleibt in der App, externe Links öffnen den Browser
  const onNav = (req) => {
    const u = req.url || '';
    if (u.startsWith(ORIGIN) || u.startsWith('about:') || u.startsWith('data:')) return true;
    Linking.openURL(u).catch(() => {});
    return false;
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: bg }} edges={['top', 'bottom', 'left', 'right']}>
        <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
        <WebView
          ref={web}
          source={{ html, baseUrl: ORIGIN }}
          originWhitelist={['*']}
          javaScriptEnabled
          domStorageEnabled
          setSupportMultipleWindows={false}
          overScrollMode="never"
          textZoom={100}
          onMessage={onMessage}
          onShouldStartLoadWithRequest={onNav}
          onNavigationStateChange={(s) => setCanGoBack(s.canGoBack)}
          style={{ flex: 1, backgroundColor: bg }}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
}
