# PaceAlyst – Android-App

Lauf-Rechner mit Äquivalenz, Splits, Prognose, Laktat und Zonen. Die App ist eine Expo-Hülle (React Native) mit einer WebView, die die komplette PaceAlyst-Web-App offline aus dem Paket lädt. Alle Plattformen nutzen denselben Rechenkern (`web/core.js`).

## Ordner

| Pfad | Inhalt |
| --- | --- |
| `web/app.html`, `web/core.js` | Quellcode der App (UI und Rechenkern). Hier wird entwickelt. |
| `src/pacealyst-html.js` | Automatisch erzeugt aus `web/`, wird in die App gepackt |
| `App.js` | Expo-Hülle: WebView, Zurück-Taste, Teilen, externe Links |
| `app.json`, `eas.json` | App-Name, Package `app.pacealyst`, Icon, Build-Profile |
| `assets/` | Icon, adaptives Android-Icon, Splash |
| `tests/core.test.mjs` | Abnahmetests des Rechenkerns |

## Einmalig einrichten

1. Node.js LTS installieren (nodejs.org).
2. Auf GitHub ein Repository `pacealyst` anlegen und diesen Ordner hochladen.
3. Im Terminal im Projektordner:
   ```
   npm install
   npx expo install --fix
   ```
   `--fix` bringt alle Pakete auf die passenden Versionen deiner Expo-Version.

## Auf dem Handy testen (ohne Build)

```
npm start
```
QR-Code mit der App **Expo Go** (Play Store) scannen.

## APK bauen und verteilen

```
npm install -g eas-cli
eas login
eas init
npm run apk
```
Nach etwa 10–15 Minuten liefert EAS einen Download-Link zur APK. Den Link an Testpersonen schicken; beim Installieren muss auf Android „Apps aus unbekannten Quellen“ erlaubt werden.

Für den Play Store später: `eas build -p android --profile production` erzeugt ein App-Bundle (.aab).

## Änderungen an der App

1. In `web/app.html` oder `web/core.js` ändern.
2. `npm test` (Rechenkern prüfen), `npm run build:web` (erzeugt `src/pacealyst-html.js` und `dist/index.html` für den Browser).
3. In `app.json` `version` und `android.versionCode` erhöhen, dann `npm run apk`.

Gespeicherte Eingaben liegen im WebView-Speicher des Geräts (Herkunft `https://pacealyst.app/`). Diese Adresse in `App.js` nicht ändern, sonst sind die Eingaben nach einem Update weg.
