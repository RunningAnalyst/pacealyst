// Baut aus web/app.html + web/core.js die eingebettete App für die WebView (und dist/index.html für den Browser)
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
const root = new URL('..', import.meta.url);
const app = readFileSync(new URL('web/app.html', root), 'utf8');
const core = readFileSync(new URL('web/core.js', root), 'utf8');
if (!app.includes('/*CORE*/')) throw new Error('Platzhalter /*CORE*/ fehlt in web/app.html');
const html = app.replace('/*CORE*/', () => core);
mkdirSync(new URL('src/', root), { recursive: true });
mkdirSync(new URL('dist/', root), { recursive: true });
writeFileSync(new URL('src/pacealyst-html.js', root), '// Automatisch erzeugt mit npm run build:web, nicht von Hand bearbeiten\nexport default ' + JSON.stringify(html) + ';\n');
writeFileSync(new URL('dist/index.html', root), html);
console.log('PaceAlyst gebaut:', (html.length / 1024).toFixed(0), 'KB');
