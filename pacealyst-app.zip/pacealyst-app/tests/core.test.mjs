// Abnahmetests Rechenkern (Lastenheft Kap. 13). Start: npm test
import { createRequire } from 'node:module';
import assert from 'node:assert/strict';
const PL = createRequire(import.meta.url)('../web/core.js');
const ok = (name, fn) => { fn(); console.log('✓', name); };
ok('Riegel 25:00 auf 5 km → 52:07 auf 10 km', () => assert.equal(PL.fmtTime(PL.riegel(1500, 5, 10)), '52:07'));
ok('Daniels-Wert 5 km 19:57 = 50,0', () => assert.equal(PL.vdot(5000, 1197).toFixed(1), '50.0'));
ok('Daniels-T-Pace bei 50 = 4:15', () => assert.equal(PL.fmtTime(PL.danielsPaces(50).T), '4:15'));
ok('Minetti 5 % ≈ +30 %', () => assert.ok(Math.abs(PL.minetti(0.05) / 3.6 - 1.30) < 0.01));
ok('Schuh: Langsame gewinnen mehr Tempo', () => {
  const fast = 1 - PL.shoeTime(10800, 42195, 4) / 10800, slow = 1 - PL.shoeTime(16200, 42195, 4) / 16200;
  assert.ok(slow > fast);
});
for (const strat of ['linear', 'defensiv', 'offensiv', 'canova', 'flagge']) ok(`Splits ${strat}: Summe = Zielzeit`, () => {
  const p = PL.splitPlan({ distKm: 42.195, target: 9900, segKm: 1, strat, s: 0.03, blockKm: 1, hi: 1.03, lo: 0.97, startPct: .15, startSlow: .02, finPct: .1, finFast: .02 });
  assert.equal(p.rows.reduce((a, r) => a + r.split, 0), 9900);
});
const st = [[12, 1.3, 136], [13, 1.1, 143], [14, 1.1, 150], [15, 1.2, 157], [16, 1.5, 164], [17, 2.1, 171], [18, 3.2, 178], [19, 5.0, 184], [20, 8.1, 189]].map(([v, la, hr]) => ({ v, la, hr }));
const L = PL.analyzeLactate(st, { stepMin: 4 });
ok('Laktat: R² ≥ 0,95, LT1 < LT2', () => { assert.ok(L.r2 >= 0.95); assert.ok(L.lt1 < L.lt2); });
ok('Spot-Check: höchstens 3 %, richtige Richtung', () => {
  const r = PL.spotCheck({ lak: L, vNow: 15.7, laNow: 2.9, lo: 2.0, hi: 2.5 });
  assert.ok(r.dv < 0 && Math.abs(r.dv) <= 15.7 * 0.03 + 1e-9);
});
