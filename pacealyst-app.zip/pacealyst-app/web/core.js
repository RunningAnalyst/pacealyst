/* PaceAlyst Rechenkern – reine Funktionen, plattformunabhängig, versioniert */
(function (root) {
'use strict';
const ALG = { kern: '1.2.0', pace: 'pace-1.0', splits: 'splits-1.0', gelaende: 'minetti-1.0', prognose: 'prog-1.0',
  daniels: 'daniels-1.0', laktat: 'lak-1.0', spot: 'spot-1.0', zonen: 'zonen-1.0', material: 'shoe-1.0' };
const KM_PER_MI = 1.609344;
const pad = n => String(n).padStart(2, '0');
const clamp = (x, a, b) => Math.max(a, Math.min(b, x));

function num(s) {
  if (typeof s === 'number') return s;
  if (s == null) return NaN;
  s = String(s).trim().replace(',', '.');
  return s === '' ? NaN : Number(s);
}
function parseTime(s) {
  if (s == null) return NaN;
  s = String(s).trim().replace(/,/g, '.');
  if (!s) return NaN;
  const p = s.split(':');
  if (p.length > 3) return NaN;
  let t = 0;
  for (const x of p) { if (x === '' || isNaN(+x)) return NaN; t = t * 60 + (+x); }
  return t;
}
function fmtTime(sec, opt) {
  opt = opt || {};
  if (!isFinite(sec)) return '–';
  const neg = sec < 0; sec = Math.abs(sec);
  const r = Math.round(sec);
  const h = Math.floor(r / 3600), m = Math.floor((r % 3600) / 60), s = r % 60;
  const str = (h || opt.h) ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
  return (neg ? '−' : '') + str;
}
function fmtNum(x, d) { return isFinite(x) ? x.toFixed(d == null ? 1 : d).replace('.', ',') : '–'; }
const kmh2pace = k => 3600 / k;
const pace2kmh = p => 3600 / p;

/* ---------- Statistik ---------- */
function linreg(xs, ys) {
  const n = xs.length; if (n < 2) return null;
  let mx = 0, my = 0; for (let i = 0; i < n; i++) { mx += xs[i]; my += ys[i]; } mx /= n; my /= n;
  let sxx = 0, sxy = 0, syy = 0;
  for (let i = 0; i < n; i++) { sxx += (xs[i] - mx) ** 2; sxy += (xs[i] - mx) * (ys[i] - my); syy += (ys[i] - my) ** 2; }
  if (sxx === 0) return null;
  const m = sxy / sxx, b = my - m * mx;
  let sse = 0; for (let i = 0; i < n; i++) sse += (ys[i] - (m * xs[i] + b)) ** 2;
  return { m, b, sse, r2: syy ? 1 - sse / syy : 1 };
}
function solve(A, y) {
  const n = y.length; A = A.map((r, i) => r.concat([y[i]]));
  for (let c = 0; c < n; c++) {
    let p = c; for (let r = c + 1; r < n; r++) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
    [A[c], A[p]] = [A[p], A[c]];
    if (Math.abs(A[c][c]) < 1e-12) return null;
    for (let r = 0; r < n; r++) if (r !== c) { const f = A[r][c] / A[c][c]; for (let k = c; k <= n; k++) A[r][k] -= f * A[c][k]; }
  }
  return A.map((r, i) => r[n] / r[i]);
}
function polyfit(xs, ys, deg) {
  const n = xs.length, mx = xs.reduce((a, b) => a + b, 0) / n;
  const sx = (Math.max(...xs) - Math.min(...xs)) / 2 || 1;
  const u = xs.map(x => (x - mx) / sx), k = deg + 1;
  const A = Array.from({ length: k }, () => Array(k).fill(0)), y = Array(k).fill(0);
  for (let i = 0; i < n; i++) for (let r = 0; r < k; r++) {
    y[r] += ys[i] * u[i] ** r;
    for (let c = 0; c < k; c++) A[r][c] += u[i] ** (r + c);
  }
  const c = solve(A, y); if (!c) return null;
  const f = x => { const t = (x - mx) / sx; let s = 0; for (let j = k - 1; j >= 0; j--) s = s * t + c[j]; return s; };
  const d = x => { const t = (x - mx) / sx; let s = 0; for (let j = k - 1; j >= 1; j--) s = s * t + j * c[j]; return s / sx; };
  return { f, d, coef: c };
}
const median = a => { const s = a.slice().sort((x, y) => x - y), n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : NaN; };
function wMedian(items) {
  const s = items.slice().sort((a, b) => a.t - b.t), W = s.reduce((a, b) => a + b.w, 0);
  let acc = 0; for (const x of s) { acc += x.w; if (acc >= W / 2 - 1e-9) return x.t; }
  return NaN;
}

/* ---------- Äquivalenz & Prognose ---------- */
const riegel = (t1, d1, d2, b) => t1 * Math.pow(d2 / d1, b == null ? 1.06 : b);
const personalExp = (d1, t1, d2, t2) => Math.log(t2 / t1) / Math.log(d2 / d1);

// Daniels/Gilbert (1979): VO2-Kosten und Anteil VO2max nach Dauer
const dVO2 = v => -4.60 + 0.182258 * v + 0.000104 * v * v; // v in m/min
const dPct = tm => 0.8 + 0.1894393 * Math.exp(-0.012778 * tm) + 0.2989558 * Math.exp(-0.1932605 * tm);
function vdot(dm, ts) { const tm = ts / 60; return dVO2(dm / tm) / dPct(tm); }
function danielsTime(V, dm) {
  let lo = 10, hi = 172800;
  for (let i = 0; i < 100; i++) { const mid = (lo + hi) / 2; if (vdot(dm, mid) > V) lo = mid; else hi = mid; }
  return (lo + hi) / 2;
}
function vAtVO2(vo2) { const a = 0.000104, b = 0.182258, c = -4.60 - vo2; return (-b + Math.sqrt(b * b - 4 * a * c)) / (2 * a); }
const paceAtVO2 = vo2 => 60000 / vAtVO2(vo2);
function danielsPaces(V) {
  return {
    E: [paceAtVO2(0.70 * V), paceAtVO2(0.62 * V)],
    M: danielsTime(V, 42195) / 42.195,
    T: paceAtVO2(0.88 * V),
    I: paceAtVO2(V),
    R: danielsTime(V, 1609.344) / 1.609344
  };
}
// Vickers & Vertosick (2016), Modell 1: Marathon aus 1 Rennen + Wochenumfang
function vickersVertosick(t1, d1km, weeklyKm) {
  const vR = 42195 / riegel(t1, d1km, 42.195, 1.07);
  const vm = 0.16018617 + 0.83076202 * vR + 0.06423826 * (weeklyKm / KM_PER_MI / 10);
  return 42195 / vm;
}
function criticalSpeed(tests) {
  const v = tests.filter(x => x.dm > 0 && x.ts > 0);
  if (v.length < 2) return null;
  const r = linreg(v.map(x => x.ts), v.map(x => x.dm));
  if (!r || !(r.m > 0)) return null;
  return { cs: r.m, dprime: r.b, r2: r.r2, n: v.length };
}
const csTime = (cs, dm) => (dm - cs.dprime) / cs.cs;

// Material: % Tempo je % Ökonomie, tempoabhängig (Näherung an Kipp, Kram & Hoogkamer 2019)
function shoeSpeedFactor(v) { const t = (v - 2.605) / (5.81 - 2.605); return clamp(1.17 + t * (0.67 - 1.17), 0.6, 1.25); }
function shoeTime(t, dm, econPct) { const f = shoeSpeedFactor(dm / t); return t / (1 + econPct * f / 100); }

function predict(o) {
  const races = (o.races || []).filter(r => r.dkm > 0 && r.t > 0);
  const T = o.targetKm; if (!races.length || !(T > 0)) return null;
  const notes = [], out = [];
  const prim = races.slice().sort((a, b) => Math.abs(Math.log(a.dkm / T)) - Math.abs(Math.log(b.dkm / T)))[0];
  const isM = Math.abs(T - 42.195) < 0.05;
  const boost = (isM && Math.abs(prim.dkm - 21.0975) < 0.05) ? 1.5 : 1;
  out.push({ id: 'riegel', t: riegel(prim.t, prim.dkm, T), w: boost });
  if (races.length >= 2 && Math.abs(races[0].dkm - races[1].dkm) > 0.01) {
    const e = personalExp(races[0].dkm, races[0].t, races[1].dkm, races[1].t);
    out.push({ id: 'pers', t: riegel(prim.t, prim.dkm, T, e), w: 1.5 * boost, e });
    if (e < 1.0 || e > 1.2) notes.push({ code: 'persOut', e });
  }
  const V = vdot(prim.dkm * 1000, prim.t);
  out.push({ id: 'daniels', t: danielsTime(V, T * 1000), w: boost, V });
  if (isM && o.weeklyKm > 0) out.push({ id: 'vv', t: vickersVertosick(prim.t, prim.dkm, o.weeklyKm), w: 2 });
  if (o.cs) {
    const t = csTime(o.cs, T * 1000), valid = t >= 120 && t <= 1800;
    out.push({ id: 'cs', t, w: valid ? 1 : 0, valid });
  }
  if (isM && prim.dkm < 21) notes.push({ code: 'shortForM' });
  const used = out.filter(x => x.w > 0 && isFinite(x.t) && x.t > 0);
  return { models: out, median: wMedian(used), lo: Math.min(...used.map(x => x.t)), hi: Math.max(...used.map(x => x.t)), prim, V, notes };
}

/* ---------- Gelände (Minetti 2002) ---------- */
function minetti(i) { i = clamp(i, -0.45, 0.45); return 155.4 * i ** 5 - 30.4 * i ** 4 - 43.3 * i ** 3 + 46.3 * i ** 2 + 19.5 * i + 3.6; }
function haversine(a, b) {
  const R = 6371.0088, r = Math.PI / 180, dLa = (b.lat - a.lat) * r, dLo = (b.lon - a.lon) * r;
  const h = Math.sin(dLa / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLo / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
function gpxProfile(pts) {
  pts = pts.filter(p => isFinite(p.lat) && isFinite(p.lon));
  if (pts.length < 2) return null;
  const d = [0]; for (let i = 1; i < pts.length; i++) d.push(d[i - 1] + haversine(pts[i - 1], pts[i]));
  const raw = pts.map(p => isFinite(p.ele) ? p.ele : NaN);
  if (raw.every(isNaN)) return null;
  for (let i = 0; i < raw.length; i++) if (isNaN(raw[i])) raw[i] = i ? raw[i - 1] : raw.find(x => !isNaN(x));
  const W = 5, e = raw.map((_, i) => { let s = 0, n = 0; for (let j = Math.max(0, i - W); j <= Math.min(raw.length - 1, i + W); j++) { s += raw[j]; n++; } return s / n; });
  let gain = 0, loss = 0; for (let i = 1; i < e.length; i++) { const de = e[i] - e[i - 1]; if (de > 0) gain += de; else loss -= de; }
  return { d, e, total: d[d.length - 1], gain, loss };
}
function eleAt(p, x) {
  let lo = 0, hi = p.d.length - 1;
  if (x <= 0) return p.e[0]; if (x >= p.total) return p.e[hi];
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (p.d[m] <= x) lo = m; else hi = m; }
  const span = p.d[hi] - p.d[lo]; return span > 0 ? p.e[lo] + (p.e[hi] - p.e[lo]) * (x - p.d[lo]) / span : p.e[lo];
}
function terrainFactors(prof, segs, distKm, hill) {
  const k = prof.total / distKm, C0 = minetti(0);
  return segs.map(sg => {
    let acc = 0, len = 0;
    for (let a = sg.from; a < sg.to - 1e-9; a += 0.05) {
      const b = Math.min(a + 0.05, sg.to), l = b - a;
      const g = (eleAt(prof, b * k) - eleAt(prof, a * k)) / ((b - a) * k * 1000);
      let f = minetti(g) / C0; if (f > 1) f = 1 + (f - 1) * (1 - hill);
      acc += f * l; len += l;
    }
    return { f: acc / len, grade: (eleAt(prof, sg.to * k) - eleAt(prof, sg.from * k)) / (sg.len * k * 1000) };
  });
}

/* ---------- Splits ---------- */
function segments(distKm, segKm) {
  const a = []; let x = 0;
  while (x < distKm - 1e-9) { const l = Math.min(segKm, distKm - x); a.push({ from: x, to: x + l, len: l }); x += l; }
  if (a.length > 1 && a[a.length - 1].len < 0.02) { const t = a.pop(); a[a.length - 1].to = t.to; a[a.length - 1].len += t.len; }
  return a;
}
function strategyFactor(sg, distKm, o) {
  const xm = (sg.from + sg.to) / 2 / distKm;
  switch (o.strat) {
    case 'defensiv': return 1 + o.s * (0.5 - xm);
    case 'offensiv': return 1 - o.s * (0.5 - xm);
    case 'canova': { const blk = Math.floor(((sg.from + sg.to) / 2) / o.blockKm); return 1 / (blk % 2 === 0 ? o.hi : o.lo); }
    case 'flagge': return xm < o.startPct ? 1 + o.startSlow : (xm > 1 - o.finPct ? 1 - o.finFast : 1);
    default: return 1;
  }
}
function splitPlan(o) {
  if (!(o.distKm > 0 && o.target > 0 && o.segKm > 0)) return null;
  const segs = segments(o.distKm, o.segKm), base = o.target / o.distKm;
  const fS = segs.map(sg => strategyFactor(sg, o.distKm, o));
  const terr = o.profile ? terrainFactors(o.profile, segs, o.distKm, o.hill || 0) : null;
  const f = fS.map((x, i) => x * (terr ? terr[i].f : 1));
  const rawS = segs.reduce((a, sg, i) => a + sg.len * base * fS[i], 0);
  const raw = segs.reduce((a, sg, i) => a + sg.len * base * f[i], 0), scale = o.target / raw;
  let cumExact = 0, prevR = 0;
  const rows = segs.map((sg, i) => {
    const t = sg.len * base * f[i] * scale; cumExact += t;
    const cumR = Math.round(cumExact), split = cumR - prevR; prevR = cumR;
    return { ...sg, t, split, cum: cumR, pace: t / sg.len, grade: terr ? terr[i].grade : null };
  });
  const half = o.distKm / 2;
  let h1 = 0; for (const r of rows) { if (r.to <= half + 1e-9) h1 += r.t; else if (r.from < half) h1 += r.t * (half - r.from) / r.len; }
  return { rows, rawDev: rawS - o.target, total: prevR, h1, h2: o.target - h1 };
}

/* ---------- Laktat ---------- */
function segReg2(xs, ys) {
  const n = xs.length; let best = null;
  for (let k = 3; k <= n - 3; k++) {
    const a = linreg(xs.slice(0, k), ys.slice(0, k)), b = linreg(xs.slice(k), ys.slice(k));
    if (!a || !b) continue; const sse = a.sse + b.sse;
    if (!best || sse < best.sse) best = { a, b, k, sse };
  }
  if (!best || best.b.m <= best.a.m) return null;
  const x = (best.a.b - best.b.b) / (best.b.m - best.a.m);
  return clamp(x, xs[0], xs[n - 1]);
}
function segReg3(xs, ys) {
  const n = xs.length; let best = null;
  for (let i = 2; i <= n - 4; i++) for (let j = i + 2; j <= n - 2; j++) {
    const a = linreg(xs.slice(0, i), ys.slice(0, i)), b = linreg(xs.slice(i, j), ys.slice(i, j)), c = linreg(xs.slice(j), ys.slice(j));
    if (!a || !b || !c) continue; const sse = a.sse + b.sse + c.sse;
    if (!best || sse < best.sse) best = { j, sse };
  }
  return best ? xs[best.j] : null;
}
const LT_METHODS = [
  { id: 'loglog', g: 'LT1', std: true }, { id: 'vl2', g: 'LT1' }, { id: 'b05', g: 'LT1' }, { id: 'b10', g: 'LT1' }, { id: 'lemin', g: 'LT1' },
  { id: 'moddmax', g: 'LT2', std: true }, { id: 'dmax', g: 'LT2' }, { id: 'vl4', g: 'LT2' }, { id: 'vl3', g: 'LT2' },
  { id: 'dickhuth', g: 'LT2' }, { id: 'ltp', g: 'LT2' }
];
function analyzeLactate(stages, opt) {
  opt = opt || {};
  const st = stages.filter(s => s.v > 0 && s.la > 0).sort((a, b) => a.v - b.v);
  if (st.length < 4) return { error: 'Mindestens 4 gültige Stufen nötig (empfohlen ab 6).' };
  const xs = st.map(s => s.v), ys = st.map(s => s.la);
  const fit = polyfit(xs, ys, 3); if (!fit) return { error: 'Kurve nicht berechenbar. Stufen prüfen.' };
  const my = ys.reduce((a, b) => a + b, 0) / ys.length;
  const ssr = ys.reduce((a, y, i) => a + (y - fit.f(xs[i])) ** 2, 0), sst = ys.reduce((a, y) => a + (y - my) ** 2, 0);
  const r2 = sst ? 1 - ssr / sst : 1;
  const x0 = xs[0], xn = xs[xs.length - 1], N = 800, g = [];
  for (let i = 0; i <= N; i++) g.push(x0 + (xn - x0) * i / N);
  const fg = g.map(fit.f); let iMin = 0; fg.forEach((y, i) => { if (y < fg[iMin]) iMin = i; });
  const speedAt = L => {
    if (fg[iMin] >= L) return null;
    for (let i = iMin + 1; i <= N; i++) if (fg[i] >= L) return g[i - 1] + (g[i] - g[i - 1]) * (L - fg[i - 1]) / (fg[i] - fg[i - 1]);
    return null;
  };
  const argmaxLine = (xa, ya, xb, yb) => {
    let best = null, bv = -Infinity;
    for (let i = 0; i <= N; i++) { if (g[i] < xa || g[i] > xb) continue; const line = ya + (yb - ya) * (g[i] - xa) / (xb - xa), dlt = line - fg[i]; if (dlt > bv) { bv = dlt; best = g[i]; } }
    return bv > 0 ? best : null;
  };
  const R = {};
  const base = Math.min(...ys.slice(0, 3));
  R.vl2 = speedAt(2); R.vl3 = speedAt(3); R.vl4 = speedAt(4);
  R.b05 = speedAt(base + 0.5); R.b10 = speedAt(base + 1.0);
  let le = null, leV = Infinity; for (let i = 0; i <= N; i++) if (fg[i] > 0 && fg[i] / g[i] < leV) { leV = fg[i] / g[i]; le = g[i]; }
  if (le === g[0] || le === g[N]) le = null; // Minimum am Rand = nicht bestimmbar
  R.lemin = le; R.dickhuth = le != null ? speedAt(fit.f(le) + 1.5) : null;
  R.dmax = argmaxLine(x0, fit.f(x0), xn, fit.f(xn));
  let si = ys.findIndex((y, i) => i < ys.length - 1 && ys[i + 1] - y > 0.4);
  R.moddmax = (si >= 0 && si < xs.length - 2) ? argmaxLine(xs[si], fit.f(xs[si]), xn, fit.f(xn)) : null;
  R.loglog = xs.length >= 6 ? (() => { const v = segReg2(xs.map(Math.log), ys.map(Math.log)); return v != null ? Math.exp(v) : null; })() : null;
  R.ltp = xs.length >= 6 ? segReg3(xs, ys) : null;
  const hrPts = st.filter(s => s.hr > 0), hrFit = hrPts.length >= 2 ? linreg(hrPts.map(s => s.v), hrPts.map(s => s.hr)) : null;
  const hrAt = v => hrFit ? hrFit.m * v + hrFit.b : NaN;
  const methods = LT_METHODS.map(m => ({ ...m, v: R[m.id], la: R[m.id] != null ? fit.f(R[m.id]) : null, hr: R[m.id] != null ? hrAt(R[m.id]) : NaN }));
  const cons = grp => { const v = methods.filter(m => m.g === grp && m.v != null).map(m => m.v); return v.length ? { v: median(v), lo: Math.min(...v), hi: Math.max(...v), n: v.length } : null; };
  const c1 = cons('LT1'), c2 = cons('LT2');
  const std1 = R.loglog != null ? R.loglog : (c1 && c1.v), std2 = R.moddmax != null ? R.moddmax : (c2 && c2.v);
  // Plausibilität
  const P = [];
  if (st.length < 6) P.push({ lv: 'warn', code: 'few', n: st.length });
  if (opt.stepMin > 0 && opt.stepMin < 3) P.push({ lv: 'warn', code: 'step', m: opt.stepMin });
  if (opt.rest > 2) P.push({ lv: 'warn', code: 'rest' });
  if (r2 < 0.95) P.push({ lv: 'warn', code: 'r2', r2 });
  if (ys.filter(y => y > 4).length < 2) P.push({ lv: 'warn', code: 'lt2few' });
  for (let i = 1; i < st.length; i++) if (st[i].hr > 0 && st[i - 1].hr > 0 && st[i].hr < st[i - 1].hr) { P.push({ lv: 'warn', code: 'hrdrop', i }); break; }
  if (c2 && c2.hi - c2.lo > 0.8) P.push({ lv: 'info', code: 'span', d: c2.hi - c2.lo });
  
  return {
    st, fit, r2, x0, xn, g, fg, speedAt,
    boundAt: L => { const v = speedAt(L); return v != null ? v : (fg[iMin] >= L ? 'below' : 'above'); }, hrAt, hrFit, methods, c1, c2, lt1: std1, lt2: std2, vmax: xn, base, plaus: P,
    slopeAt: v => fit.d(v), version: ALG.laktat
  };
}

/* ---------- Spot-Check ---------- */
function spotCheck(o) {
  let k, exact = true;
  if (o.lak && !o.lak.error) { k = o.lak.slopeAt(o.vNow); if (o.vNow < o.lak.x0 || o.vNow > o.lak.xn) exact = false; }
  else { k = 1.2; exact = false; }
  k = Math.max(k, 0.3);
  const mid = (o.lo + o.hi) / 2, inRange = o.laNow >= o.lo && o.laNow <= o.hi;
  const target = inRange ? o.laNow : mid;
  let dv = (target - o.laNow) / k * (o.damp == null ? 0.6 : o.damp);
  const cap = o.vNow * (o.maxPct == null ? 3 : o.maxPct) / 100, capped = Math.abs(dv) > cap;
  dv = clamp(dv, -cap, cap);
  const vNew = o.vNow + dv;
  return { k, exact, inRange, target, dv, vNew, paceNew: 3600 / vNew, paceNow: 3600 / o.vNow, capped,
    suspect: o.laNow - o.hi > 3, version: ALG.spot };
}

const PL = { ALG, KM_PER_MI, num, parseTime, fmtTime, fmtNum, kmh2pace, pace2kmh, linreg, polyfit, median, wMedian,
  riegel, personalExp, vdot, danielsTime, danielsPaces, paceAtVO2, vickersVertosick, criticalSpeed, csTime, shoeSpeedFactor, shoeTime,
  predict, minetti, gpxProfile, terrainFactors, segments, splitPlan, analyzeLactate, LT_METHODS, spotCheck, clamp };
if (typeof module !== 'undefined' && module.exports) module.exports = PL; else root.PL = PL;
})(this);
